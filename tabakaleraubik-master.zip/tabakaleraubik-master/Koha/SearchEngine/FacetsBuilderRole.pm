package Koha::SearchEngine::FacetsBuilderRole;

use Moose::Role;

requires 'build_facets';

1;
