package Koha::SearchEngine::QueryBuilderRole;

use Moose::Role;

requires 'build_query';

1;
