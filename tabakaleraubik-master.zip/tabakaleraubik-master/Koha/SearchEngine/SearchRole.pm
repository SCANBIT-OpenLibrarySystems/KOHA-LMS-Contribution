package Koha::SearchEngine::SearchRole;
use Moose::Role;

requires 'search';
requires 'dosmth';

1;
