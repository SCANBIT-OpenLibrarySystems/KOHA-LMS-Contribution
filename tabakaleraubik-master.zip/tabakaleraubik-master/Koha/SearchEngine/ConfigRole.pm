package Koha::SearchEngine::ConfigRole;

use Moose::Role;

requires 'indexes', 'index', 'ressource_types';

1;
