package Koha::SearchEngine::IndexRole;
use Moose::Role;

requires 'index_record';

1;
